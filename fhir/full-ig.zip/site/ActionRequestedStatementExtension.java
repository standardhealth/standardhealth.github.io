package http://standardhealthrecord.org/fhir/ImplementationGuide/1;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class ActionRequestedStatementExtension {

}
